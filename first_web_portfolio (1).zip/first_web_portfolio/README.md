# Personal Portfolio Website

A beginner portfolio website built with HTML and CSS.

## About
This project introduces me as a first-year Computer Science Engineering student who is learning web development.

## Built with
- HTML5
- CSS3
- A small JavaScript snippet for the current year

## Before publishing
1. Replace `Your Name` and `YN` with your name and initials.
2. Replace the example email with your real professional email.
3. After creating a GitHub repository, add its URL to the project section.
4. Keep skills accurate—only list technologies you have actually practised.

## Run locally
Open `index.html` in a web browser.
